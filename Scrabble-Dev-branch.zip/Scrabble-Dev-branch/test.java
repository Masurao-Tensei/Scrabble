package projet;

/*import javax.swing.JFrame;
import java.awt.Graphics;
import javax.swing.JPanel;*/

public class test {
	public static void main(String[] args){
		
	    plateau1 plateau = new plateau1();
	    //Plateau2 plateau2= new Plateau2();
	    //plateau2.setVisible(true);
	}
}
